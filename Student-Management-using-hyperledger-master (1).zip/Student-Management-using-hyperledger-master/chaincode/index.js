/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const MySmartContractContract = require('./lib/my-smart-contract-contract');

module.exports.MySmartContractContract = MySmartContractContract;
module.exports.contracts = [ MySmartContractContract ];
